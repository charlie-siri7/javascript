// Imports
import React from 'react'
import { Container, VStack, Text, SimpleGrid } from '@chakra-ui/react'
import { Link } from 'react-router-dom';
import { useStore } from '../store/item';
import { useEffect } from 'react';
import ItemCard from "@/components/ui/ItemCard"
import { ToastContainer } from 'react-toastify';
import "react-toastify/dist/ReactToastify.css";
// Function to make the home page
const Home = () => {
  // items is the state variable of the useStore() function
  const { getItems, items } = useStore();
  // useEffect function to get items
  useEffect(() => {
    getItems();
  }, [getItems]);
  // Print items to console
  console.log("items: ", items);
  return (
    // Return the home page HTML - a container containing a VStack and a toast container
    <Container maxW="container.xl" py={12}>
      <VStack spacing={8}>
        {/* Title of home page */}
        <Text fontSize={30}
          fontWeight={"bold"}
          color='cyan.400'
          textAlign={"center"}>
          Current Items
        </Text>
        {/* Grid that scales the column count based on size of screen */}
        <SimpleGrid columns={{
          base: 1,
          md: 2,
          lg: 3
        }}
        spacing={10}
        w={"full"}>
          {/* Each object of the grid is an itemCard mapped to an item in the database */}
          {items.map((item) => (
            <ItemCard key={item._id} item={item} />
          ))}
        </SimpleGrid>
        {/* Only run if there are no products */}
        {items.length === 0 && (
        <Text
          fontSize="xl"
          textAlign="center"
          fontWeight="bold"
          color="gray.500"
        >
          {/* Text saying there are no items */}
          No items{" "}
          {/* Link to create page for creating an item */}
          <Link to="/create">
            {/* span - underline when mouseover, no underline when no mouseover */}
            <span
              style={{
                color: "#3b82f6",
                textDecoration: "none",
                cursor: "pointer",
                display: "inline-block",
              }}
              onMouseOver={(e) => e.currentTarget.style.textDecoration = "underline"}
              onMouseOut={(e) => e.currentTarget.style.textDecoration = "none"}
            >
              {/* The text of the link */}
              Create an item
            </span>
          </Link>
        </Text>
        )}
      </VStack>
      <ToastContainer/>
    </Container>
  );
}
{/* Export the home page */}
export default Home