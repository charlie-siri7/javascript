// Imports from react, chakra, item.js
import { React, useState } from 'react'
import { Container, VStack, Heading, Box, Input, Button } from "@chakra-ui/react";
import { useStore } from '../store/item';
import { toast, ToastContainer } from 'react-toastify';
import "react-toastify/dist/ReactToastify.css";
// Function to return the create page
const Create = () => {
  // Item is the state variable of an item; contains name, price, image
  const [item, setItem] = useState({
    name: "",
    price: "",
    image: "",
  });
  // Get createItem from useStore()
  const { createItem } = useStore();
  // handler function for adding an item
  const addItem = async() => {
    // Call createItem and get whether it is successful
    const {success, message} = await createItem(item);
    if (success) {
      // Toast if item is created successfully
      toast.success("Item created successfully.", {
          position: 'bottom-center',
      });
    } else {
      // Toast if there's an error creating the item
      toast.error("Error creating item.", {
          position: 'bottom-center',
      });
    }
    // Clear fields for createItem() after it is called
    setItem({ name: "", price: "", image: "" });
  };
  // Return the HTML of the create page
  return (
    // Container with the VStack of the create page
    <Container maxW={"container.sm"}>
      <VStack spacing={8}>
        {/* Create Page header */}
        <Heading as={"h1"}
          size={"2xl"}
          textAlign={"center"}
          mb={8}>
          Create New Item
        </Heading>
        {/* Box with decorations to contain the input bars */}
        <Box w={"full"}
          bg={"gray.800"}
          p={6}
          rounded={"lg"}
          shadow={"md"}
          > 
            {/* Input bars organized in VStack */}
            <VStack spacing={4}>
              {/* For each input bar: placeholder, name, value of current item (empty), sets item when a change
              is made to the input bar */}
              <Input placeholder="Name:"
                name="name"
                value={item.name}
                onChange={(e) => setItem({...item, name: e.target.value})}/>
              <Input placeholder="Price:"
                name="price"
                type="number"
                value={item.price}
                onChange={(e) => setItem({...item, price: e.target.value})}/>
              <Input placeholder="Image URL:"
                name="image"
                value={item.image}
                onChange={(e) => setItem({...item, image: e.target.value})}/>
              {/* Button to finalize adding the item */}
              <Button colorPalette="blue" onClick={addItem} w="full">Add Item</Button>
              {/* Toast container to display success or failure when adding item */}
              <ToastContainer/>
            </VStack>
          </Box>
      </VStack>
    </Container>
  )
}

export default Create