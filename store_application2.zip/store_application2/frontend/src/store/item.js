// Create import from zustand - used for state management
import { create } from "zustand";
// useStore function - has all methods to perform actions on items
export const useStore = create((set) => ({
    // list of items
    items: [],
    // function to set items
    setItems: (items) => set({ items }),
    // function to create an item
    createItem: async (item) => {
        // Return error if user doesn't fill out at least 1 field.
        if (!item.name || !item.image || !item.price) {
            return {success: false, message: "At least 1 field not filled out."};
        }
        // response is used to fetch the data and get its JSON content
        const response = await fetch("http://localhost:5000/api/items", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(item),
        });
        // data is the data of the fetched JSON
        const data = await response.json();
        // Set the state to the items and their data, return that new item successfully created
        set((state) => ({ items: [...state.items, data.data] }));
        return { success: true, message: "Item successfully created." };
    },
    // Function to get an item from the database
    getItems: async () => {
        // Fetch json content from api
        const response = await fetch("http://localhost:5000/api/items", {
            headers: {
                'Content-Type': 'application/json',
            }
        });
        // Get the data from the json content
        const data = await response.json();
        // Set items to correspond to their data
        set({ items: data.data });
    },
    // Function to delete an item with a given ID
    deleteItem: async (itemID) => {
        // response is the result of trying to fetch and delete the data with the given ID.
        const response = await fetch(`http://localhost:5000/api/items/${itemID}`, {
            method: "DELETE",
        });
        // data is the data of the json content
        const data = await response.json();
        // Return with error if getting data doesn't succeed
        if (!data.success) {
            return { success: false, message: data.message };
        }
        // update UI in real time
        set(state => ({ items: state.items.filter(item => item._id !== itemID) }));
        // Return success if everything up to the end is successful
        return { success: true, message: data.message };
    },
    // Function to update the value of an item with a given ID
    updateItem: async (itemID, updatedItem) => {
        // Try a put call on the item with the given ID; stringify JSON
        const response = await fetch(`http://localhost:5000/api/items/${itemID}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(updatedItem),
        });
        // get data from JSON content, return error if it doesn't work
        const data = await response.json();
        if (!data.success) {
            return { success: false, message: data.message };
        }
        // update UI in real time
        set((state) => ({ 
            items: state.items.map((item) => (item._id === itemID ? data.data : item)) 
        }));
        // Return success if everything up until this point worked
        return { success: true, message: data.message };
    },
}));